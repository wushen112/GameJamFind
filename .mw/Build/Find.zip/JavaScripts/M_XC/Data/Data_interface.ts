﻿interface Slot_Data{
    icon_id : string ;
    tag : string;
    cnt : number;
}