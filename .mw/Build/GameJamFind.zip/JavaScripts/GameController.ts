import EventController from "./EventController";
import DefaultUI from "./M_XC/DefaultUI";
import Awake_generate from "./ui-generate/Awake_generate";
import { Obj_Manager } from "./M_XC/Obj_Manager";
import GameAnimation from "./util/GameAnimaiton";
import EndTips_generate from "./ui-generate/EndTips_generate"
import Tips from "./util/Tips";
import MainUI from "./M_XC/ui/UIMain";
import BlackChange_generate from "./ui-generate/BlackChange_generate";
import StartGame_Generate from "./ui-generate/StartGame_generate";

/*
 * @Author: wushen112 330177253@qq.com
 * @Date: 2024-07-06 14:11:24
 * @LastEditors: wushen112 330177253@qq.com
 * @LastEditTime: 2024-07-07 14:53:20
 * @FilePath: \test\JavaScripts\GameController.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
export default class GameController {
    private static _insance: GameController;
    private Black: BlackChange_generate
    public static get instance() {
        if (!this._insance) {
            this._insance = new GameController();
        }

        return this._insance;

    }


    public startCamera: Camera = null;
    public endCamera: Camera = null;
    public currCameta: Camera = null
    public hitCamera: Camera = null;
    public BagCamera: Camera = null;
    public parachuteCamera: Camera = null;
    private EndTips: EndTips_generate
    onUpdate() {

    }
    LoopFrist() {

        //音效
        let soundNao = GameObject.findGameObjectById("17357BC7") as Sound
        let soundQueen = GameObject.findGameObjectById("01EC1A8F") as Sound
        let soundBao = GameObject.findGameObjectById("3E1551CA") as Sound
        //特效
        const effect = GameObject.findGameObjectById("2C6CFD01") as Effect;
        let hud = UIService.show(Awake_generate)
        hud.mCanvas_Black.visibility = 0;

        // 眨眼
        let eye1Tween = new mw.Tween({ value: 1 }).to({ value: 0.2 }, 500).onUpdate((obj) => {
            hud.mCanvas_Black.renderOpacity = obj.value
        })
        let eye1BackTween = new mw.Tween({ value: 0.2 }).to({ value: 1 }, 500).onUpdate((obj) => {
            hud.mCanvas_Black.renderOpacity = obj.value
        })
        soundNao.play()
        setTimeout(() => {
            soundNao.play()
            setTimeout(() => {
                soundNao.play()
            }, 400)
        }, 400)
        setTimeout(() => {
            eye1Tween.start().chain(eye1BackTween.start())
            eye1BackTween.start().chain(eye1Tween.start())
            setTimeout(() => {
                effect.play();
                soundBao.play()
                setTimeout(() => {
                    eye1Tween.pause()
                    eye1BackTween.pause()
                    hud.mCanvas_Black.renderOpacity = 1
                    soundQueen.play()
                    setTimeout(() => {
                        soundBao.pause()
                        soundQueen.pause()
                        UIService.hide(Awake_generate)
                        //进入正式游戏写这里面
                        this.gameStart()
                    }, 3000);
                }, 500);
            }, 2000);
        }, 1400);
    }

    gameStart() {
        let hud = UIService.show(Awake_generate)
        let sound = GameObject.findGameObjectById("22185F22") as Sound
        sound.play()
        let eye1Tween = new mw.Tween({ value: 1 }).to({ value: 0 }, 800).onUpdate((obj) => {
            hud.mCanvas_Black.renderOpacity = obj.value
        }).start();
        //进入正式游戏写这里面
        setTimeout(() => {
            UIService.hide(Awake_generate)
            Tips.show("我：刚刚是梦吗");
            UIService.show(DefaultUI);
        }, 1500);
    }
    //TODO 判断死亡
    judgeDie(isJump = false) {
        if (isJump) {
            if (UIService.getUI(DefaultUI).slots.has("parachute")) {
                this.dropSuccess();
            } else {
                this.dropFail();
            }
            return;
        }


        if (EventController.instance.success1 == false) {
            this.dieBybomb();
            return;
        }
        if (EventController.instance.success2 == false) {
            this.airCollision();
            return;
        }

        this.win();
    }


    reset() {
        UIService.hide(EndTips_generate)
        Camera.switch(GameController.instance.currCameta, 0)
        EventController.instance.success1 = false;
        EventController.instance.success2 = false;
        UIService.getUI(DefaultUI).slots.clear();
        UIService.getUI(DefaultUI).update_slot();
        UIService.getUI(DefaultUI).time = 30;
        GameController.instance.gameStart();
        Obj_Manager.instance.init_obj();
        EventController.instance.terroristState = false
        
        let air = GameObject.findGameObjectById("28F0DA02") as Character
        let airAnima = air.loadAnimation("157422")
        airAnima.loop = 0;
        airAnima.slot = AnimSlot.Upper;
        airAnima.play()

        let ikun = GameObject.findGameObjectById("1D4A1AED") as Character
        let ikunAnima = ikun.loadAnimation("285778")
        ikunAnima.loop = 0;
        ikunAnima.slot = AnimSlot.Upper;
        ikunAnima.play()

    }

    /**爆炸死亡  */
    dieBybomb() {
        const effect = GameObject.findGameObjectById("0318B5B8") as Effect;
        effect.loopCount = 3;
        this.EndTips = UIService.show(EndTips_generate)
        this.EndTips.mText_Take.text = "飞机内部发生了爆炸，无人幸免"
        Camera.switch(GameController.instance.hitCamera, 0)
        setTimeout(() => {
            effect.play();
        }, 500);
        setTimeout(() => {
            this.reset()
        }, 2000);

    }
    public tempPos :Vector = Vector.zero

    airCollision() {
        const airA = GameObject.findGameObjectById("2293A559") as GameObject;
        const airB = GameObject.findGameObjectById("1F8FDF36") as GameObject;
        const effect = GameObject.findGameObjectById("0BDCEFE5") as Effect;
        const airAPosition = airA.worldTransform.position.clone();
        const airBPosition = airB.worldTransform.position.clone();
        this.tempPos = airB.worldTransform.position.clone();
        Camera.switch(GameController.instance.hitCamera, 0)
        let airTween = new mw.Tween(airBPosition).to(airAPosition, 2000).onUpdate((value) => {
            airB.worldTransform.position = value
        }).start();
        setTimeout(() => {
            this.EndTips = UIService.show(EndTips_generate)
            this.EndTips.mText_Take.text = "飞机发生了撞击，无人幸免"
            effect.play();
        }, 1000);
        setTimeout(() => {
            airB.worldTransform.position = this.tempPos;
            this.reset()
        }, 4000);
    }
    /**掉落结局 */
    dropFail() {
        this.Black = UIService.show(BlackChange_generate)
        this.Black.mImg_take.text = "一跃而下，如同飞鸟"
        Camera.switch(GameController.instance.BagCamera, 0.2)
        setTimeout(() => {
            UIService.hide(BlackChange_generate)
        }, 1000);
        setTimeout(() => {
            this.EndTips = UIService.show(EndTips_generate)
            this.EndTips.mText_Take.text = "大部分人从高空跳下都会摔死"
            setTimeout(() => {
                UIService.hide(EndTips_generate)
                this.reset()
            }, 2000);
        }, 2000);
    }
    dropSuccess() {
        this.Black = UIService.show(BlackChange_generate)
        this.Black.mImg_take.text = "一跃而下，如同飞鸟"
        Camera.switch(GameController.instance.parachuteCamera, 0.2)
        setTimeout(() => {
            UIService.hide(BlackChange_generate)
        }, 1000);

        setTimeout(() => {
            UIService.hide(EndTips_generate)
            this.EndTips = UIService.show(EndTips_generate)
            this.EndTips.mText_Take.text = "你成功避免了死亡，但你本可成为拯救他人的英雄"
            setTimeout(() => {
                this.reset();
            }, 2000);
        }, 2000);
    }

    /**真正胜利的结局 */
    win() {
        this.Black = UIService.show(BlackChange_generate)
        this.Black.mImg_take.text = "这之后一路无事发生，平安落地"
        const air = GameObject.findGameObjectById("3481F2C3") as GameObject;
        let sound = GameObject.findGameObjectById("15C6D457") as Sound
        Camera.switch(GameController.instance.endCamera)
        setTimeout(() => {
            UIService.hide(BlackChange_generate)
            setTimeout(() => {
                sound.play()
                this.EndTips = UIService.show(EndTips_generate)
                this.EndTips.mText_Take.text = "你做到了，成功拯救了众人！"
                setTimeout(() => {
                    this.reset();
                    Camera.switch(GameController.instance.startCamera, 0)
                    UIService.hide(EndTips_generate)
                    UIService.show(StartGame_Generate)
                    UIService.hide(DefaultUI)
                }, 3000);
            }, 300);
        }, 1500);
    }

}

export enum Ending {
    dieBybomb,
    airCollision,
    dropFail,
    dropWin,
    win
}
